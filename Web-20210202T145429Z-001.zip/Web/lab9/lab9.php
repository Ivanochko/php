<?php


require("../config.php");
include_once("../db.php");
include_once("../function.php");
header("Content-Type: text/html; charset=".$config{'charset'});
echo "<a href=bd1.php><H1> <p>Побудова БД</p></H1></a>";
?>

<html>
<title>lab9</title> 


</html>
